package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VentanaInicio extends JFrame {

//	private JLabel logo, empresa, ueb, fondo, img1, img2;
//	private JButton jugar, salir;
//	private JPanel panel;
//
//	public VentanaInicio() {
//
//		setTitle("UNO TEACHER");
//		setSize(1280, 720);
//		setLayout(new GridLayout(3, 3));
//		setResizable(false);
//		setVisible(true);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//		jugar = new JButton("HOLASDAFAEF");
//		jugar.setVisible(true);
//		jugar.setBackground(Color.black);
//		jugar.setForeground(Color.white);
//		add(jugar);
//
//	}
//
//	public JLabel getLogo() {
//		return logo;
//	}
//
//	public void setLogo(JLabel logo) {
//		this.logo = logo;
//	}
//
//	public JLabel getEmpresa() {
//		return empresa;
//	}
//
//	public void setEmpresa(JLabel empresa) {
//		this.empresa = empresa;
//	}
//
//	public JLabel getUeb() {
//		return ueb;
//	}
//
//	public void setUeb(JLabel ueb) {
//		this.ueb = ueb;
//	}
//
//	public JLabel getFondo() {
//		return fondo;
//	}
//
//	public void setFondo(JLabel fondo) {
//		this.fondo = fondo;
//	}
//
//	public JLabel getImg1() {
//		return img1;
//	}
//
//	public void setImg1(JLabel img1) {
//		this.img1 = img1;
//	}
//
//	public JLabel getImg2() {
//		return img2;
//	}
//
//	public void setImg2(JLabel img2) {
//		this.img2 = img2;
//	}
//
//	public JButton getJugar() {
//		return jugar;
//	}
//
//	public void setJugar(JButton jugar) {
//		this.jugar = jugar;
//	}
//
//	public JButton getSalir() {
//		return salir;
//	}
//
//	public void setSalir(JButton salir) {
//		this.salir = salir;
//	}
//
//	public JPanel getPanel() {
//		return panel;
//	}
//
//	public void setPanel(JPanel panel) {
//		this.panel = panel;
//	}

}
