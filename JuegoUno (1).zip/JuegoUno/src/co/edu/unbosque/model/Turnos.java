package co.edu.unbosque.model;
import java.util.Stack;

public class Turnos {

	  private int numeroDeJugadores; 
	  private int turnoActual;
	  private boolean sentidoHorario;
	  private Carta cartaActual; 


	  public Turnos(int numeroDeJugadores) {
	    this.numeroDeJugadores = numeroDeJugadores;
	    this.turnoActual = 0; 
	    this.sentidoHorario = true; 
	    this.cartaActual = null;
	  }

	 
	  public Carta obtenerCartaActual() {
	    return this.cartaActual;
	  }

	  public void actualizarCartaActual(Carta cartaJugada) {
		    this.cartaActual = cartaJugada;
		    if (cartaActual.esCartaValida(cartaActual)) {
		        switch (cartaJugada.getTipo()) {
		            case REVERSA:
		                this.sentidoHorario = !this.sentidoHorario;
		                break;
		            case SALTA:
		                this.avanzarTurno();
		                break;
		            case TOMA_DOS:
		                this.avanzarTurno();
		                break;
		            case COMODIN:
		                break;
		            case COMODIN_ROBA4:
		                this.avanzarTurno();
		                break;
		        }
		    }
		}

	  public void avanzarTurno() {
	    if (this.sentidoHorario) {
	      this.turnoActual = (this.turnoActual + 1) % this.numeroDeJugadores;
	    } else {
	      this.turnoActual = (this.turnoActual - 1 + this.numeroDeJugadores) % this.numeroDeJugadores;
	    }
	  }

	  public int obtenerTurnoActual() {
	    return this.turnoActual;
	  }

	}

