package co.edu.unbosque.model;

public enum TipoCarta {
    NORMAL,
    REVERSA,
    SALTA,
    TOMA_DOS,
    COMODIN,
    COMODIN_ROBA4
}



