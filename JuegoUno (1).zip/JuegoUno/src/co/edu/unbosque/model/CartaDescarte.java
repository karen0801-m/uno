package co.edu.unbosque.model;

import java.util.Stack;

public class CartaDescarte {
//	private Stack<Carta> cartaDescarte;
//
//	public CartaDescarte() {
//		cartaDescarte = new Stack<>();
//	}
//
//	public void agregarCarta(Carta carta) {
//		if (cartaDescarte.size() >= 3) {
//			cartaDescarte.remove(0);
//		}
//		cartaDescarte.push(carta);
//	}
//
//	public Stack<Carta> getCartaDescarte() {
//		return cartaDescarte;
//	}
//
//	public Carta peek() {
//		if (!cartaDescarte.isEmpty()) {
//			return cartaDescarte.peek();
//		}
//		return null;
//	}
//
//	public boolean isEmpty() {
//		return cartaDescarte.isEmpty();
//	}
//
//	public void setCartaDescarte(Stack<Carta> cartaDescarte) {
//		this.cartaDescarte = cartaDescarte;
//	}
//	
}
