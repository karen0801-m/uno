package co.edu.unbosque.model;
import co.edu.unbosque.model.Mazo;

public class Bots {
    private Mano mano;
    public Bots() {
        mano = new Mano();
    }

    public void realizarMovimiento() {
        for (int i = 0; i < mano.obtenerCantidadCartas(); i++) {
            Carta carta = mano.obtenerCarta(i);
            if (puedeJugarCarta(carta)) {
                jugarCarta(carta);
                return;
            }
        }
        tomarCartaDelMazo();
    }

    private boolean puedeJugarCarta(Carta carta) {
        if (carta.isEmpty()) {
            return true;
        }
        Carta cartaDescarte = carta.peek();
        return carta.getNumero() == carta.getNumero() || carta.getColor() == carta.getColor();
    }

    private void jugarCarta(Carta carta) {
        Carta carta1 = new Carta(); 
        carta.agregarCarta(carta);
        mano.removerCarta(carta);
    }


    private void tomarCartaDelMazo() {
    	Mazo mazo = new Mazo();
        Carta carta = mazo.tomarCarta();
        mano.agregarCarta(carta);
    }
    
    public boolean haGanado() {
        return mano.obtenerCantidadCartas() == 0;
    }
}
