package co.edu.unbosque.model;
import co.edu.unbosque.model.TipoCarta;

import java.util.Stack;

public class Carta {
    private Color color;
    private int numero;
    private Simbolo simbolo;
    public Mazo mazo;
    private TipoCarta tipo;
    private Stack<Carta> cartaDescarte;

    public Carta() {
        mazo = new Mazo();
        cartaDescarte = new Stack<>();
    }

    public enum Color {
        ROJO, AMARILLO, VERDE, AZUL
    }

    public enum Simbolo {
        NUMERO, REVERSA, SALTO, MAS2, CAMBIO_COLOR, MAS4
    }

    public Carta(Color color, int numero, Simbolo simbolo) {
        this.color = color;
        this.numero = numero;
        this.simbolo = simbolo;
    }

    public Color getColor() {
        return color;
    }

    public int getNumero() {
        return numero;
    }

    public Simbolo getSimbolo() {
        return simbolo;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setSimbolo(Simbolo simbolo) {
        this.simbolo = simbolo;
    }

    public boolean esCartaValida(Carta cartaActual) {
        Carta cartaTope = mazo.getCartaActual();
        if (cartaTope.getColor() == cartaActual.getColor() || cartaTope.getNumero() == cartaActual.getNumero()
                || cartaTope.getTipo() == cartaActual.getTipo()) {
            return true;
        } else if (cartaTope.getTipo() == TipoCarta.COMODIN || cartaTope.getTipo() == TipoCarta.COMODIN_ROBA4) {
            return true;
        }

        return false;
    }

    public void agregarCarta(Carta carta) {
        if (cartaDescarte.size() >= 3) {
            cartaDescarte.remove(0);
        }
        cartaDescarte.push(carta);
    }

    public Stack<Carta> getCartaDescarte() {
        return cartaDescarte;
    }

    public Carta peek() {
        if (!cartaDescarte.isEmpty()) {
            return cartaDescarte.peek();
        }
        return null;
    }

    public boolean isEmpty() {
        return cartaDescarte.isEmpty();
    }

    public void setCartaDescarte(Stack<Carta> cartaDescarte) {
        this.cartaDescarte = cartaDescarte;
    }

    public Mazo getMazo() {
        return mazo;
    }

    public void setMazo(Mazo mazo) {
        this.mazo = mazo;
    }

    public TipoCarta getTipo() {
        return tipo;
    }

    public void setTipo(TipoCarta tipo) {
        this.tipo = tipo;
    }
}
