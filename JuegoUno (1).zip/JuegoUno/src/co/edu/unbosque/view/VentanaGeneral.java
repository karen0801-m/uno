package co.edu.unbosque.view;

public class VentanaGeneral {

	private VentanaPrincipal vp;
	private VentanaJuego vj;
	private ChatBot ventanaChat;

	public VentanaGeneral() {
		vj = new VentanaJuego();
		vp = new VentanaPrincipal();
		ventanaChat = new ChatBot();
	}
	
	public void mostrarChat() {
		ventanaChat.mostrar();
	}

	public VentanaPrincipal getVp() {
		return vp;
	}

	public void setVp(VentanaPrincipal vp) {
		this.vp = vp;
	}

	public VentanaJuego getVj() {
		return vj;
	}

	public void setVj(VentanaJuego vj) {
		this.vj = vj;
	}

	public ChatBot getVentanaChat() {
		return ventanaChat;
	}

	public void setVentanaChat(ChatBot ventanaChat) {
		this.ventanaChat = ventanaChat;
	}

}

