package co.edu.unbosque.view;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Image;
import java.awt.image.BufferedImage;

import java.io.File;
import java.io.IOException;

public class VentanaPartida extends JFrame {

	private JButton turn, history, chat, uno, alert, j1, j2, j3, robos, descartes;
	private JFrame ventana;
	private JLabel img, back;

	public VentanaPartida() {
		ventana = new JFrame("¡UNO TEACHER!");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(1280, 800);
		ventana.setResizable(false);
		ventana.setLayout(null);
		run();
	}

	public void run() {

		turn = new JButton("Turno");
		turn.setBounds(10, 10, 180, 80);
		turn.setActionCommand("turn");
		turn.setContentAreaFilled(false);
		turn.setFocusPainted(false);
		turn.setBorderPainted(false);
		BufferedImage bi1 = null;
		try {
			img = new JLabel();
			bi1 = ImageIO.read(new File("src/Turno.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado1 = bi1.getScaledInstance(turn.getWidth(), turn.getHeight(), Image.SCALE_SMOOTH);
		turn.setIcon(new ImageIcon(redimensionado1));
		ventana.add(turn);

		history = new JButton("Historial");
		history.setBounds(1070, 10, 180, 80);
		history.setActionCommand("history");
		history.setContentAreaFilled(false);
		history.setFocusPainted(false);
		history.setBorderPainted(false);
		BufferedImage bi2 = null;
		try {
			img = new JLabel();
			bi2 = ImageIO.read(new File("src/Historial.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado2 = bi2.getScaledInstance(history.getWidth(), history.getHeight(), Image.SCALE_SMOOTH);
		history.setIcon(new ImageIcon(redimensionado2));
		ventana.add(history);

		chat = new JButton("Chat");
		chat.setBounds(10, 660, 250, 90);
		chat.setActionCommand("chat");
		chat.setContentAreaFilled(false);
		chat.setFocusPainted(false);
		chat.setBorderPainted(false);
		BufferedImage bi3 = null;
		try {
			img = new JLabel();
			bi3 = ImageIO.read(new File("src/Chat.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado3 = bi3.getScaledInstance(chat.getWidth(), chat.getHeight(), Image.SCALE_SMOOTH);
		chat.setIcon(new ImageIcon(redimensionado3));
		ventana.add(chat);

		uno = new JButton("¡UNO!");
		uno.setBounds(990, 630, 120, 120);
		uno.setActionCommand("uno");
		uno.setContentAreaFilled(false);
		uno.setFocusPainted(false);
		uno.setBorderPainted(false);
		BufferedImage bi4 = null;
		try {
			img = new JLabel();
			bi4 = ImageIO.read(new File("src/Uno.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado4 = bi4.getScaledInstance(uno.getWidth(), uno.getHeight(), Image.SCALE_SMOOTH);
		uno.setIcon(new ImageIcon(redimensionado4));
		ventana.add(uno);

		alert = new JButton("ALERTA");
		alert.setBounds(1130, 630, 120, 120);
		alert.setActionCommand("alert");
		alert.setContentAreaFilled(false);
		alert.setFocusPainted(false);
		alert.setBorderPainted(false);
		BufferedImage bi5 = null;
		try {
			img = new JLabel();
			bi5 = ImageIO.read(new File("src/Alerta.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado5 = bi5.getScaledInstance(alert.getWidth(), alert.getHeight(), Image.SCALE_SMOOTH);
		alert.setIcon(new ImageIcon(redimensionado5));
		ventana.add(alert);

		j1 = new JButton("j1");
		j1.setBounds(290, 500, 700, 150);
		j1.setContentAreaFilled(false);
		j1.setFocusPainted(false);
		j1.setBorderPainted(false);
		ventana.add(j1);

		j2 = new JButton("j2");
		j2.setBounds(100, 100, 150, 400);
		j2.setContentAreaFilled(false);
		j2.setFocusPainted(false);
		j2.setBorderPainted(false);
		ventana.add(j2);

		j3 = new JButton("j3");
		j3.setBounds(1040, 100, 150, 400);
		j3.setContentAreaFilled(false);
		j3.setFocusPainted(false);
		j3.setBorderPainted(false);
		ventana.add(j3);

		robos = new JButton("Robos");
		robos.setBounds(350, 200, 190, 280);
		robos.setActionCommand("stealth");
		robos.setContentAreaFilled(false);
		robos.setFocusPainted(false);
		robos.setBorderPainted(false);
		BufferedImage bi9 = null;
		try {
			img = new JLabel();
			bi9 = ImageIO.read(new File("src/Back.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado9 = bi9.getScaledInstance(robos.getWidth(), robos.getHeight(), Image.SCALE_SMOOTH);
		robos.setIcon(new ImageIcon(redimensionado9));
		ventana.add(robos);

		descartes = new JButton("Descartes");
		descartes.setBounds(750, 200, 190, 280);
		descartes.setContentAreaFilled(false);
		descartes.setFocusPainted(false);
		descartes.setBorderPainted(false);
		ventana.add(descartes);

		back = new JLabel();
		back.setBounds(0, 0, ventana.getWidth(), ventana.getHeight());
		back.setOpaque(false); //
		BufferedImage fondoImg = null;
		try {
			fondoImg = ImageIO.read(new File("src/Background.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image fondoRedimensionado = fondoImg.getScaledInstance(back.getWidth(), back.getHeight(), Image.SCALE_SMOOTH);
		back.setIcon(new ImageIcon(fondoRedimensionado));
		ventana.add(back);

		ventana.setVisible(false);

	}

	public JButton getTurn() {
		return turn;
	}

	public void setTurn(JButton turn) {
		this.turn = turn;
	}

	public JButton getHistory() {
		return history;
	}

	public void setHistory(JButton history) {
		this.history = history;
	}

	public JButton getChat() {
		return chat;
	}

	public void setChat(JButton chat) {
		this.chat = chat;
	}

	public JButton getUno() {
		return uno;
	}

	public void setUno(JButton uno) {
		this.uno = uno;
	}

	public JButton getAlert() {
		return alert;
	}

	public void setAlert(JButton alert) {
		this.alert = alert;
	}

	public JButton getJ1() {
		return j1;
	}

	public void setJ1(JButton j1) {
		this.j1 = j1;
	}

	public JButton getJ2() {
		return j2;
	}

	public void setJ2(JButton j2) {
		this.j2 = j2;
	}

	public JButton getJ3() {
		return j3;
	}

	public void setJ3(JButton j3) {
		this.j3 = j3;
	}

	public JButton getRobos() {
		return robos;
	}

	public void setRobos(JButton robos) {
		this.robos = robos;
	}

	public JButton getDescartes() {
		return descartes;
	}

	public void setDescartes(JButton descartes) {
		this.descartes = descartes;
	}

	public JFrame getVentana() {
		return ventana;
	}

	public void setVentana(JFrame ventana) {
		this.ventana = ventana;
	}

	public JLabel getImg() {
		return img;
	}

	public void setImg(JLabel img) {
		this.img = img;
	}

	public JLabel getBack() {
		return back;
	}

	public void setBack(JLabel back) {
		this.back = back;
	}

}
