package co.edu.unbosque.view;

import javax.imageio.ImageIO;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Image;
import java.awt.image.BufferedImage;

import java.io.File;
import java.io.IOException;

public class VentanaInicio extends JFrame {

	private JButton jugar, salir;
	private JFrame ventana;
	private JLabel logocorp, logo, api, back, img;

	public VentanaInicio() {

		ventana = new JFrame("¡Bienvenido a UNO TEACHER!");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(1024, 800);
		ventana.setResizable(false);
		ventana.setLayout(null);
		run();
	}

	public void run() {

		jugar = new JButton("Jugar");
		jugar.setBounds(290, 320, 450, 190);
		jugar.setActionCommand("play");
		jugar.setContentAreaFilled(false);
		jugar.setFocusPainted(false);
		jugar.setBorderPainted(false);
		BufferedImage bi1 = null;
		try {
			img = new JLabel();
			bi1 = ImageIO.read(new File("src/Jugar.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado1 = bi1.getScaledInstance(jugar.getWidth(), jugar.getHeight(), Image.SCALE_SMOOTH);
		jugar.setIcon(new ImageIcon(redimensionado1));
		ventana.add(jugar);

		salir = new JButton("Salir");
		salir.setBounds(20, 650, 250, 100);
		salir.setActionCommand("leave");
		salir.setContentAreaFilled(false);
		salir.setFocusPainted(false);
		salir.setBorderPainted(false);
		BufferedImage bi2 = null;
		try {
			img = new JLabel();
			bi2 = ImageIO.read(new File("src/Salir.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado2 = bi2.getScaledInstance(salir.getWidth(), salir.getHeight(), Image.SCALE_SMOOTH);
		salir.setIcon(new ImageIcon(redimensionado2));
		ventana.add(salir);

		api = new JLabel();
		api.setBounds(-150, -150, 670, 500);
		BufferedImage bi3 = null;
		try {
			img = new JLabel();
			bi3 = ImageIO.read(new File("src/UNO_Logo.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado3 = bi3.getScaledInstance(api.getWidth(), api.getHeight(), Image.SCALE_SMOOTH);
		api.setIcon(new ImageIcon(redimensionado3));
		ventana.add(api);

		logo = new JLabel();
		logo.setBounds(700, 20, 270, 200);
		BufferedImage bi4 = null;
		try {
			img = new JLabel();
			bi4 = ImageIO.read(new File("src/UEB.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado4 = bi4.getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
		logo.setIcon(new ImageIcon(redimensionado4));
		ventana.add(logo);

		logocorp = new JLabel();
		logocorp.setBounds(700, 600, 370, 200);
		BufferedImage bi5 = null;
		try {
			img = new JLabel();
			bi5 = ImageIO.read(new File("src/Logos.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado5 = bi5.getScaledInstance(logocorp.getWidth(), logocorp.getHeight(), Image.SCALE_SMOOTH);
		logocorp.setIcon(new ImageIcon(redimensionado5));
		ventana.add(logocorp);

		back = new JLabel();
		back.setBounds(0, 0, ventana.getWidth(), ventana.getHeight());
		BufferedImage fondoImg = null;
		try {
			fondoImg = ImageIO.read(new File("src/Background.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image fondoRedimensionado = fondoImg.getScaledInstance(back.getWidth(), back.getHeight(), Image.SCALE_SMOOTH);
		back.setIcon(new ImageIcon(fondoRedimensionado));
		ventana.add(back);

		ventana.setVisible(true);

	}

	public JButton getJugar() {
		return jugar;
	}

	public void setJugar(JButton jugar) {
		this.jugar = jugar;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public JFrame getVentana() {
		return ventana;
	}

	public void setVentana(JFrame ventana) {
		this.ventana = ventana;
	}

	public JLabel getLogocorp() {
		return logocorp;
	}

	public void setLogocorp(JLabel logocorp) {
		this.logocorp = logocorp;
	}

	public JLabel getLogo() {
		return logo;
	}

	public void setLogo(JLabel logo) {
		this.logo = logo;
	}

	public JLabel getApi() {
		return api;
	}

	public void setApi(JLabel api) {
		this.api = api;
	}

	public JLabel getBack() {
		return back;
	}

	public void setBack(JLabel back) {
		this.back = back;
	}

	public JLabel getImg() {
		return img;
	}

	public void setImg(JLabel img) {
		this.img = img;
	}

}
