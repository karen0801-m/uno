package co.edu.unbosque.view;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VentanaGanador extends JFrame {

	private JButton volver;
	private JLabel img, back, win, winner;
	private JFrame ventana;

	public VentanaGanador() {
		ventana = new JFrame("GANADOR");
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setSize(1280, 800);
		ventana.setResizable(false);
		ventana.setLayout(null);
		run();
	}

	public void run() {

		volver = new JButton("Volver");
		volver.setBounds(10, 660, 250, 90);
		volver.setActionCommand("back");
		volver.setContentAreaFilled(false);
		volver.setFocusPainted(false);
		volver.setBorderPainted(false);
		BufferedImage bi1 = null;
		try {
			img = new JLabel();
			bi1 = ImageIO.read(new File("src/Volver.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado1 = bi1.getScaledInstance(volver.getWidth(), volver.getHeight(), Image.SCALE_SMOOTH);
		volver.setIcon(new ImageIcon(redimensionado1));
		ventana.add(volver);

		win = new JLabel();
		win.setBounds(470, 120, 290, 490);
		BufferedImage bi2 = null;
		try {
			img = new JLabel();
			bi2 = ImageIO.read(new File("src/Ganador.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image redimensionado2 = bi2.getScaledInstance(win.getWidth(), win.getHeight(), Image.SCALE_SMOOTH);
		win.setIcon(new ImageIcon(redimensionado2));
		ventana.add(win);

		winner = new JLabel("");
		winner.setBounds(400, 10, 1000, 100);
		Font font = new Font(winner.getFont().getName(), Font.BOLD, 48);
		winner.setFont(font);
		ventana.add(winner);

		back = new JLabel();
		back.setBounds(0, 0, ventana.getWidth(), ventana.getHeight());
		back.setOpaque(false); //
		BufferedImage fondoImg = null;
		try {
			fondoImg = ImageIO.read(new File("src/Background.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Image fondoRedimensionado = fondoImg.getScaledInstance(back.getWidth(), back.getHeight(), Image.SCALE_SMOOTH);
		back.setIcon(new ImageIcon(fondoRedimensionado));
		ventana.add(back);

		ventana.setVisible(false);

	}

	public JButton getVolver() {
		return volver;
	}

	public void setVolver(JButton volver) {
		this.volver = volver;
	}

	public JLabel getImg() {
		return img;
	}

	public void setImg(JLabel img) {
		this.img = img;
	}

	public JLabel getBack() {
		return back;
	}

	public void setBack(JLabel back) {
		this.back = back;
	}

	public JLabel getWin() {
		return win;
	}

	public void setWin(JLabel win) {
		this.win = win;
	}

	public JFrame getVentana() {
		return ventana;
	}

	public void setVentana(JFrame ventana) {
		this.ventana = ventana;
	}

}
