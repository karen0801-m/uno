package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import co.edu.unbosque.model.Bots;
import co.edu.unbosque.model.Fachada;
import co.edu.unbosque.model.Jugador;
import co.edu.unbosque.view.ChatBot;
import co.edu.unbosque.view.VentanaGanador;
import co.edu.unbosque.view.VentanaInicio;
import co.edu.unbosque.view.VentanaPartida;
import co.edu.unbosque.view.VentanaPrincipal;

public class Controller implements ActionListener {

	private VentanaPrincipal ventanaPrincipal;

	private VentanaInicio vi;
	private VentanaPartida vp;
	private VentanaGanador vg;

	private ChatBot ventanaChat;
	private Jugador jugador;
	private Bots bot1;
	private Bots bot2;
	private Fachada fachada;

	public Controller() {
		ventanaPrincipal = new VentanaPrincipal();
		vi = new VentanaInicio();
		vp = new VentanaPartida();
		vg = new VentanaGanador();
		asignarOyentes();
		fachada = new Fachada();
		ventanaChat = new ChatBot();
		bot1 = new Bots();
		bot2 = new Bots();

	}

	public void iniciar() {
//		ventanaPrincipal.mostrar();
	}

	public void asignarOyentes() {
		ventanaPrincipal.getChatButton().addActionListener(this);

		vi.getJugar().addActionListener(this);
		vi.getJugar().setActionCommand("play"); // Boton para ejecutar la ventana de juego

		vi.getSalir().addActionListener(this);
		vi.getSalir().setActionCommand("leave"); // Boton para salir

		vp.getTurn().addActionListener(this);
		vp.getTurn().setActionCommand("turn"); // Boton para ver el turno

		vp.getHistory().addActionListener(this);
		vp.getHistory().setActionCommand("history"); // Boton de Historial

		vp.getChat().addActionListener(this);
		vp.getChat().setActionCommand("chat"); // Boton de chat

		vp.getUno().addActionListener(this);
		vp.getUno().setActionCommand("uno"); // Boton de uno (NO SE HIZO FUNCIONALIDAD)

		vp.getAlert().addActionListener(this);
		vp.getAlert().setActionCommand("alert"); // Boton de Alerta (NO SE HIZO FUNCIONALIDAD)

		vp.getRobos().addActionListener(this);
		vp.getRobos().setActionCommand("stealth"); // Boton de robar

		vg.getVolver().addActionListener(this);
		vg.getVolver().setActionCommand("back"); // Boton para volver de la ventana ganador a la inicial
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("play")) {
			vi.getVentana().setVisible(false);
			vp.getVentana().setVisible(true);
		}

		if (e.getActionCommand().equals("back")) {
			vg.getVentana().setVisible(false);
			vi.getVentana().setVisible(true);
		}

		if (e.getActionCommand().equals("leave")) {
			System.exit(0);
		}

		if (e.getActionCommand().equals("turn")) {

			int aux = 0;
			aux = fachada.getTurnos().obtenerTurnoActual();
			JOptionPane.showMessageDialog(null, "Estamos en el turno: " + aux);

		}

		if (e.getActionCommand().equals("history")) {

		}

		if (e.getActionCommand().equals("chat")) {

			abrirVentanaChat();

		}

		if (e.getActionCommand().equals("uno")) {

			// No hay funcionalidad

		}

		if (e.getActionCommand().equals("alert")) {

			// No hay funcionalidad

		}

		if (e.getActionCommand().equals("stealth")) {

			fachada.getMazo().tomarCarta();

		}
	}

	private void abrirVentanaChat() {
		ventanaChat = new ChatBot();
		mostrarVentanaChat();
		jugarPartida();
	}

	private void mostrarVentanaChat() {
		ventanaChat.mostrar();
	}

	private void jugarPartida() {
		while (!fachada.jugadorHaGanado() && !bot1.haGanado() && !bot2.haGanado()) {
			bot1.realizarMovimiento();
			bot2.realizarMovimiento();
			fachada.realizarMovimientoJugador();
		}
	}

}
